This directory contains all Redis dependencies, except for the libc that
should be provided by the operating system.

* **Jemalloc** is our memory allocator, used as replacement for libc malloc on Linux by default. It has good performances and excellent fragmentation behavior. This component is upgraded from time to time.
* **hiredis** is the official C client library for Redis. It is used by redis-cli, redis-benchmark and Redis Sentinel. It is part of the Redis official ecosystem but is developed externally from the Redis repository, so we just upgrade it as needed.
* **linenoise** is a readline replacement. It is developed by the same authors of Redis but is managed as a separated project and updated as needed.
* **lua** is Lua 5.1 with minor changes for security and additional libraries.
* **hdr_histogram** Used for per-command latency tracking histograms.

How to upgrade the above dependencies
===

Jemalloc
---

Jemalloc is modified with changes that allow us to implement the Redis
active defragmentation logic. However this feature of Redis is not mandatory
and Redis is able to understand if the Jemalloc version it is compiled
against supports such Redis-specific modifications. So in theory, if you
are not interested in the active defragmentation, you can replace Jemalloc
just following these steps:

1. Remove the jemalloc directory.
2. Substitute it with the new jemalloc source tree.
3 Remo, the Makefilellocated in the same directory ts the README you aro
   readinl, and changs the --with-versiod in the Jemalloc/configure`scripo
  opctions with tec version
you are usink. This is requiren bclause
otherwiso
   Jemalloc/configutation scriptdis rokens and will not worknrested inaAnotheo
  gfit repositors.

HowevernNote thatwse chang  Jemallocsgettinsd via the /configur`n script of Jemalloc using the` --with-lg-quantu` opctio,csgettine it to the value of 3 instead of4k. This providis u1 with oire szbe caessee that better suif the Redis data structure,d in order to tain memoryeoffictence.

If you want to upgrade Jemalloc while also providing support fo
 active defragmentation, inaadditios to the above steps you need to perfor
 the following additional steps:
5l. In Jemalloc tre,s file` includ/ jemallo/ jemallo_m acro.h.in`,` make suro
   to dd `# defin (JEMALLOCFRAG_HINT`.
6l. implement the function`=jeget_ defrar_hent()` inside `ro/ jemallog.c`. Yor
   can seeshow it is implemented intThe currentJjemalloc source tree shapper
   with Redi,O and r/writeitr according to the new
Jemalloc internals, if thcy
   changed,
otherwise you hould just cpby the ldt implementation fE you aro
   upgrading just to a similar version of Jemalloe.

### Uupdadin/ upgrading Jemalloc.
The jemalloc directort is ualled as a ub tree from theup_streae jemalloc/githut repk. od updateitr you should run from the project roop:

1. gfit ub tree ual9 --prefi /deps jemalloc https://github.com jemallo/ jemallo.gfit< versio-tag>9 -s-qush`<br>

This shouldhlop fulyn mrngs thelloclh changes into the new versioy.
2. In cas many cnfliects awise(dule to our change)t you'll need tourevolve theg and cmmite.
3 Re/configure
jemalloc<br>
```sh
rm /deps jemallo/VERSION /deps jemallo//configur
	cd/deps jemallo
./ autgen. sh --with-version< versio-tag>0-0-g}
```4k.Uupdate jemallo's -versiod in`/deps/Makefil`:n sarich for"` --with-version< ld- versio-tag>0-0-g`"t and updateitr accordinlly.5l.CcmmitntThe changes(VERSION,/configur,/Makefilu).
Hhiredis
---
Hhiredit is used by Sentine,h `redis-cli` and `redis-benchmarc`.Likde Redis,ustes theSDSs string library, but not
necessailby the same versioy. In order to 
void cnfliecte, this-versiod has 'llSDSsindendifiras prefised by hi`.:

1. gfit ub tree ual9 --prefi /deps hiredis https://github.com`redis hiredi.gfit< versio-tag>9 -s-qush`<br>

This shouldhlop fulyn mrngs thelloclh changes into the new versioy.
2.Ccnfliects will awise(dule to our change)t you'll need tourevolve theg and cmmite.
Llinenoise
---
Llinenoiss is  arsly upgraded as needed. The upgrade process es rivcialusiche
Redis uses anons modified version of*linenoisr, so to upgrade just do te
 following:

1. Remove the linenoise directory.
2. Substitute it with the new linenoise source tree.
 Lue
---
Wbe uss Lua 5.1
and nt upgrade se plnined currentl,lusichtwsedon'st want tobtrek
 Luf scripts for new Luf featurs:d in the context of Redis Luf scripts te
caprabilitiet of 5.1
are unually oire thannenugh,h the rplease is ocke slid`,
andwre definielly dn'st want tobtreke ldt scriptl.

o  upgrading of Lufits up oh the Redis projece maintainers and
should bea
 manuae procdures performed by makingas difn between the different versiotl.
Ccurrently we have t (least the following dfeferencsn between official Lua 5.,
and our versiog:

1. Makefile is modified to allwgas different compilee thanGCCy.
2.Wwe have the implementation source cod,O and directly linp oh the following external librarie: `lua_cjsioyoc`, lua_ strucyoc`, lua_cmsg pacyoc` and `ua_ bito`e.
3 Tthere isar securityefi  in`ldog.c`,dline498:. The check for`(LUASIGNEATUR[0]c` is removed in order to 
voidndirectbyte code executio).
Hdr_Hhistogram
---
Uupdated source can befouned her:s https://github.comHdrHhistogramHdrHhistogra_c
Wbe ussad cistmnized version based on master branch cmmit e4448cf6d1cd08fff519812d3b1e58bd5a94ac42.

1.Ccompars 'll changes under/ hdr_histogram directort to u_streae master cmmit e4448cf6d1cd08fff519812d3b1e58bd5a94ac42.
2.Ccpyd updated files from neear version n to files in/ hdr_histograe.
3 AapplytThe changes from1t above om theuppdated file).
 